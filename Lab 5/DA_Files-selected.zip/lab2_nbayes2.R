data(Titanic)
mdl <- naiveBayes(Survived ~ ., data = Titanic)
mdl
# etc.

